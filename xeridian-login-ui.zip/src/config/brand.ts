// Change names, colors, and text here. Nothing else in the app hardcodes them.
export const brand = {
  appName: 'Xeridian',
  tagline: 'Count every rep.',
  logo: require('../../assets/logo.png'),

  colors: {
    background: '#0F1115',
    surface: '#1A1D24',
    primary: '#3B82F6',
    primaryText: '#FFFFFF',
    text: '#F3F4F6',
    mutedText: '#9CA3AF',
    border: '#2A2F3A',
    error: '#F87171',
  },

  text: {
    login: {
      title: 'Welcome back',
      subtitle: 'Log in to keep tracking your reps.',
      emailLabel: 'Email',
      emailPlaceholder: 'you@example.com',
      passwordLabel: 'Password',
      passwordPlaceholder: 'Your password',
      submit: 'Log in',
      noAccount: "Don't have an account?",
      goToSignUp: 'Sign up',
    },
    signUp: {
      title: 'Create your account',
      subtitle: 'Start counting reps in minutes.',
      nameLabel: 'Name',
      namePlaceholder: 'Your name',
      emailLabel: 'Email',
      emailPlaceholder: 'you@example.com',
      passwordLabel: 'Password',
      passwordPlaceholder: 'At least 8 characters',
      confirmLabel: 'Confirm password',
      confirmPlaceholder: 'Repeat your password',
      submit: 'Sign up',
      haveAccount: 'Already have an account?',
      goToLogin: 'Log in',
    },
    errors: {
      nameRequired: 'Please enter your name.',
      emailInvalid: 'Please enter a valid email address.',
      passwordShort: 'Password must be at least 8 characters.',
      passwordMismatch: 'Passwords do not match.',
    },
  },
};

export type Brand = typeof brand;
