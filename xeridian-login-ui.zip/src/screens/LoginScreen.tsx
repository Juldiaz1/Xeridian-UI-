import React, { useState } from 'react';
import { Image, KeyboardAvoidingView, Platform, ScrollView, StyleSheet, Text, View } from 'react-native';
import { brand } from '../config/brand';
import Button from '../components/Button';
import TextField from '../components/TextField';

type Props = {
  onLogin: (email: string, password: string) => void;
  onGoToSignUp: () => void;
  loading?: boolean;
  errorMessage?: string;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function LoginScreen({ onLogin, onGoToSignUp, loading, errorMessage }: Props) {
  const t = brand.text.login;
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const submit = () => {
    const eErr = EMAIL_RE.test(email.trim()) ? '' : brand.text.errors.emailInvalid;
    const pErr = password.length >= 8 ? '' : brand.text.errors.passwordShort;
    setEmailError(eErr);
    setPasswordError(pErr);
    if (!eErr && !pErr) onLogin(email.trim(), password);
  };

  return (
    <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Image source={brand.logo} style={styles.logo} resizeMode="contain" />
        <Text style={styles.title}>{t.title}</Text>
        <Text style={styles.subtitle}>{t.subtitle}</Text>

        <TextField label={t.emailLabel} value={email} onChangeText={setEmail} placeholder={t.emailPlaceholder}
          keyboardType="email-address" error={emailError} />
        <TextField label={t.passwordLabel} value={password} onChangeText={setPassword} placeholder={t.passwordPlaceholder}
          secureTextEntry error={passwordError} />

        {!!errorMessage && <Text style={styles.formError}>{errorMessage}</Text>}

        <Button title={t.submit} onPress={submit} loading={loading} />

        <View style={styles.footer}>
          <Text style={styles.footerText}>{t.noAccount} </Text>
          <Text style={styles.link} onPress={onGoToSignUp}>{t.goToSignUp}</Text>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1, backgroundColor: brand.colors.background },
  container: { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logo: { width: 96, height: 96, alignSelf: 'center', marginBottom: 16 },
  title: { color: brand.colors.text, fontSize: 28, fontWeight: '700', textAlign: 'center' },
  subtitle: { color: brand.colors.mutedText, fontSize: 15, textAlign: 'center', marginTop: 6, marginBottom: 28 },
  formError: { color: brand.colors.error, fontSize: 14, textAlign: 'center', marginBottom: 12 },
  footer: { flexDirection: 'row', justifyContent: 'center', marginTop: 20 },
  footerText: { color: brand.colors.mutedText, fontSize: 15 },
  link: { color: brand.colors.primary, fontSize: 15, fontWeight: '600' },
});
