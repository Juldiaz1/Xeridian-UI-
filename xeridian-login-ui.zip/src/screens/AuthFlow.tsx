import React, { useState } from 'react';
import LoginScreen from './LoginScreen';
import SignUpScreen from './SignUpScreen';

type Props = {
  onLogin?: (email: string, password: string) => void;
  onSignUp?: (name: string, email: string, password: string) => void;
};

// Switches between login and sign-up with plain state (no navigation library needed yet).
export default function AuthFlow({ onLogin = () => {}, onSignUp = () => {} }: Props) {
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  return mode === 'login' ? (
    <LoginScreen onLogin={onLogin} onGoToSignUp={() => setMode('signup')} />
  ) : (
    <SignUpScreen onSignUp={onSignUp} onGoToLogin={() => setMode('login')} />
  );
}
