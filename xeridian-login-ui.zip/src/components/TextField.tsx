import React from 'react';
import { KeyboardTypeOptions, StyleSheet, Text, TextInput, View } from 'react-native';
import { brand } from '../config/brand';

type Props = {
  label: string;
  value: string;
  onChangeText: (text: string) => void;
  placeholder?: string;
  secureTextEntry?: boolean;
  keyboardType?: KeyboardTypeOptions;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  error?: string;
};

export default function TextField({
  label, value, onChangeText, placeholder, secureTextEntry, keyboardType, autoCapitalize = 'none', error,
}: Props) {
  return (
    <View style={styles.wrapper}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={brand.colors.mutedText}
        secureTextEntry={secureTextEntry}
        keyboardType={keyboardType}
        autoCapitalize={autoCapitalize}
        autoCorrect={false}
        style={[styles.input, !!error && styles.inputError]}
      />
      {!!error && <Text style={styles.error}>{error}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: 16 },
  label: { color: brand.colors.text, fontSize: 14, fontWeight: '500', marginBottom: 6 },
  input: {
    height: 52, borderRadius: 12, borderWidth: 1, borderColor: brand.colors.border,
    backgroundColor: brand.colors.surface, color: brand.colors.text, paddingHorizontal: 14, fontSize: 16,
  },
  inputError: { borderColor: brand.colors.error },
  error: { color: brand.colors.error, fontSize: 13, marginTop: 6 },
});
